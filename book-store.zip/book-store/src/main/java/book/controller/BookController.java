package book.controller;

import book.entity.bookEntity;
import book.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/books")
public class BookController {

	@Autowired
	private BookRepository bookRepository;

	@GetMapping
	public List<bookEntity> getAllBooks() {
		return bookRepository.findAll();
	}

	@GetMapping("/{id}")
	public ResponseEntity<bookEntity> getBookById(@PathVariable Long id) {
		Optional<bookEntity> optionalBook = bookRepository.findById(id);
		return optionalBook.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
	}
	@PostMapping
	public bookEntity createBook(@RequestBody bookEntity book) {
		return bookRepository.save(book);
	}

	// Update an existing book
	@PutMapping("/{id}")
	public ResponseEntity<bookEntity> updateBook(@PathVariable Long id, @RequestBody bookEntity updatedBook) {
		Optional<bookEntity> optionalBook = bookRepository.findById(id);
		if (optionalBook.isPresent()) {
			bookEntity existingBook = optionalBook.get();
			existingBook.setTitle(updatedBook.getTitle());
			existingBook.setAuthor(updatedBook.getAuthor());
			existingBook.setISBN(updatedBook.getISBN());
			existingBook.setPublishedDate(updatedBook.getPublishedDate());
			existingBook.setGenre(updatedBook.getGenre());

			bookRepository.save(existingBook);
			return ResponseEntity.ok(existingBook);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
		if (bookRepository.existsById(id)) {
			bookRepository.deleteById(id);
			return ResponseEntity.noContent().build();
		} else {
			return ResponseEntity.notFound().build();
		}
	}

}
