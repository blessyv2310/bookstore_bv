package book.repository;

import book.entity.bookEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<bookEntity, Long> {
	// Custom queries, if needed
}
